console.log("JavaScript")
function asdf() {
    document.body.innerHTML += "<p>Me llamo Ana Belen.</p>";
}

asdf()
