module.exports = {
    testEnvironment: 'jsdom',
  };
  